vecino_proximo -> Programa del apartado 1
insercion_mcoste -> Programa del apartado 2 (compilar con -std=c++11)
vecino_proximoV2 -> Programa propio
dif_long.cpp -> Se le pasan los siguientes parametros: puntos-tsp orden-optimo orden-obtenido-por-algoritmo . Calcula la distancia del recorrido optimo, del recorrido obtenido por alguno de los algoritmos y realiza la diferencia entre las dos distancias.
